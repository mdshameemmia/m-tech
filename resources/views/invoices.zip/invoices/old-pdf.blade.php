<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        p{
            margin: 0;
            padding: 0;
        }

        table tr td, th{
            padding: 10px 15px;
        }
    </style>
</head>
<body>
    <p>
        <img src="{{asset('images/logo.jpg')}}" width="100%" height="60px" alt="">
      </p>

    <h1 style="text-align: right;padding:0 20px">INVOICE</h1>

     <div style="width:100% ;display:flex">
        <div style="width: 50%;float:left">
            <p>{{$invoice->company->name??''}}</p>
            <p>{{$invoice->company->address??''}}</p>
            <p>Tel: {{$invoice->company->tel??''}}</p>
            <p>Fax: {{$invoice->company->fax??''}}</p>
            <p>Attention: {{$invoice->company->attention??''}}</p>
        </div>
        <div style="width: 50%;float:left">
            <p>DATE: {{date('d/m/Y',strtotime($invoice->created_at))}}</p>
            <p>INVOICE: {{$invoice->invoice_no??''}}</p>
            <p>PROGRESS CLAIM REF. : {{$invoice->progressClaim->claim_no??''}}</p>
            @php
                $certificate = explode("-",$invoice->progressClaim->claim_no);
            @endphp
            <p>PAYMENT CERTIFICATE NO:  {{$certificate[1]??''}}</p>
            <p>Ref. QUOTATION NO:  {{$quotation??''}}</p>
        </div>
     </div>

     <br>
     <div>
        <span style="font-weight: bold;color:#000">Project Title</span> : {{$invoice->title??''}}
     </div>

     <br>
     <div>
        <span style="font-weight: bold;color:#000">Project System</span>
     </div>

     <table border="1" style="border-collapse:collapse">

        <thead>
            <tr>
                <th>ITEM</th>
                <th>Description</th>
                <th>U.Price</th>
                <th>Amount</th>
            </tr>
        </thead>

        <tbody>
            {{-- @php
                $total = 0;
            @endphp
            @foreach ($quotation->productQuotations as $item)
             @php
                 $total = $total + $item->amount;
             @endphp
                <tr>
                    <td>{{$loop->iteration??''}}</td>
                    <td>{{$item->product->item_name??''}}</td>
                    <td>{{$item->product->unit??''}}</td>
                    <td>{{$item->rate??''}}</td>
                    <td>{{$item->qty??''}}</td>
                    <td>{{$item->amount??''}}</td>
                </tr>
            @endforeach
            <tr>
                <th colspan="5">Total </th>
                <th>{{$total ??""}}</th>
            </tr> --}}
        </tbody>
     </table>


     <br>
     <div>
        Yours Faithfully, <br>
        M- TECH (S) PTE LTD
     </div>
     <br>
     <br>
     <div style="border-top: 1px dotted #000;padding-top:5px">
        MR: MOTIN <br>
        Project Manager

     </div>
    
</body>
</html>